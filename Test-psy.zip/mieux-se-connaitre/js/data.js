/* Questions et interprétations des tests — modifiez ce fichier pour ajouter ou adapter des tests. */
/* ============ DONNÉES DES TESTS ============ */
const LIKERT = ["Pas du tout d’accord","Plutôt pas d’accord","Neutre","Plutôt d’accord","Tout à fait d’accord"];

const TESTS = {
 "big-five": {
  title:"Les 5 grands traits", short:"Big Five", color:"#c2552d", letter:"5",
  desc:"Le modèle de référence en psychologie pour décrire la personnalité : ouverture, conscience, extraversion, agréabilité, stabilité émotionnelle.",
  time:"4 min", type:"likert",
  intro:["Indiquez à quel point chaque phrase vous décrit tel(le) que vous êtes généralement, pas tel(le) que vous aimeriez être.","Basé sur le Mini-IPIP (20 items), une version courte et validée du modèle Big Five, issue du domaine public."],
  questions:[
   {t:"Je suis souvent l’âme de la fête.",k:"E"},
   {t:"Je suis touché(e) par les sentiments des autres.",k:"A"},
   {t:"Je fais mes tâches tout de suite, sans attendre.",k:"C"},
   {t:"Mon humeur change souvent.",k:"N"},
   {t:"J’ai une imagination débordante.",k:"O"},
   {t:"Je ne parle pas beaucoup.",k:"E",r:1},
   {t:"Je ne m’intéresse pas vraiment aux autres.",k:"A",r:1},
   {t:"J’oublie souvent de ranger les choses à leur place.",k:"C",r:1},
   {t:"Je suis détendu(e) la plupart du temps.",k:"N",r:1},
   {t:"Les idées abstraites ne m’intéressent pas.",k:"O",r:1},
   {t:"En soirée, je discute avec beaucoup de personnes différentes.",k:"E"},
   {t:"Je ressens les émotions des gens autour de moi.",k:"A"},
   {t:"J’aime l’ordre.",k:"C"},
   {t:"Je m’énerve facilement.",k:"N"},
   {t:"J’ai du mal à comprendre les idées abstraites.",k:"O",r:1},
   {t:"Je reste plutôt en retrait.",k:"E",r:1},
   {t:"Les problèmes des autres ne m’intéressent pas.",k:"A",r:1},
   {t:"Je sème souvent le désordre autour de moi.",k:"C",r:1},
   {t:"Je me sens rarement abattu(e).",k:"N",r:1},
   {t:"Je n’ai pas beaucoup d’imagination.",k:"O",r:1}
  ]
 },
 "profil": {
  title:"Profil de préférences", short:"16 profils", color:"#5b4bc4", letter:"16",
  desc:"Inspiré de la typologie de Jung : découvrez votre combinaison de préférences parmi 16 profils.",
  time:"3 min", type:"choice", noShuffle:true,
  intro:["Pour chaque situation, choisissez la réponse qui vous ressemble le plus spontanément.","Il n’y a pas de bonne ou de mauvaise réponse : chaque préférence a ses forces."],
  questions:[
   {t:"Après une semaine chargée, vous rechargez vos batteries…",o:[["En sortant voir du monde","E"],["Au calme, chez vous","I"]]},
   {t:"Vous faites davantage confiance…",o:[["Aux faits et à l’expérience","S"],["À votre intuition","N"]]},
   {t:"Face à une décision difficile, vous privilégiez…",o:[["La logique et les critères objectifs","T"],["L’impact sur les personnes","F"]]},
   {t:"Votre agenda idéal est…",o:[["Planifié à l’avance","J"],["Ouvert aux imprévus","P"]]},
   {t:"En réunion, vous avez tendance à…",o:[["Réfléchir à voix haute","E"],["Réfléchir avant de parler","I"]]},
   {t:"Quand on vous présente un projet, vous voulez d’abord…",o:[["Les détails concrets et les étapes","S"],["La vision d’ensemble et le sens","N"]]},
   {t:"Un collègue a fait une erreur. Vous…",o:[["Pointez le problème franchement pour le corriger","T"],["Prenez des gants pour ne pas le blesser","F"]]},
   {t:"Face à une échéance…",o:[["Vous terminez bien avant","J"],["L’urgence vous stimule","P"]]},
   {t:"Côté relations, vous préférez…",o:[["Un large cercle de connaissances","E"],["Quelques relations proches et profondes","I"]]},
   {t:"On vous décrit plutôt comme…",o:[["Réaliste et pratique","S"],["Imaginatif(ve) et inventif(ve)","N"]]},
   {t:"Dans une discussion, le plus important est…",o:[["D’avoir raison sur le fond","T"],["De préserver une bonne relation","F"]]},
   {t:"En voyage, vous préférez…",o:[["Un itinéraire précis","J"],["Improviser sur place","P"]]}
  ]
 },
 "communication": {
  title:"Style de communication", short:"Communication", color:"#1f8a70", letter:"C",
  desc:"Pilote, Inspirant, Facilitateur ou Analyste ? Comprenez comment vous communiquez et comment vous adapter aux autres.",
  time:"4 min", type:"choice",
  intro:["Pour chaque question, choisissez la réponse qui décrit le mieux votre comportement habituel, au travail comme dans la vie.","Les réponses sont mélangées : ne cherchez pas de logique, suivez votre premier réflexe."],
  questions:[
   {t:"En réunion, on vous reconnaît surtout parce que vous…",o:[["Allez droit au but et poussez à la décision","D"],["Apportez de l’énergie et des idées","E"],["Veillez à ce que chacun puisse s’exprimer","H"],["Posez des questions précises et vérifiez les données","M"]]},
   {t:"Pour convaincre quelqu’un, vous misez sur…",o:[["Des résultats et des arguments forts","D"],["Une histoire et de l’enthousiasme","E"],["La confiance et la relation","H"],["Des chiffres et des preuves","M"]]},
   {t:"Ce qui vous agace le plus chez un interlocuteur :",o:[["La lenteur et l’indécision","D"],["La monotonie, le manque d’enthousiasme","E"],["L’agressivité et le manque d’égards","H"],["L’imprécision et les approximations","M"]]},
   {t:"Vos e-mails sont plutôt…",o:[["Courts, avec des actions claires","D"],["Chaleureux, avec des points d’exclamation","E"],["Polis, en prenant des nouvelles","H"],["Structurés et détaillés","M"]]},
   {t:"Sous pression, vous avez tendance à…",o:[["Prendre le contrôle","D"],["Parler plus vite et plus fort","E"],["Céder pour éviter le conflit","H"],["Vous replier et analyser","M"]]},
   {t:"Votre plus grande force relationnelle :",o:[["La détermination","D"],["Le charisme","E"],["L’écoute","H"],["La rigueur","M"]]},
   {t:"Face à un désaccord, vous…",o:[["Défendez fermement votre position","D"],["Essayez de rallier l’autre avec conviction","E"],["Cherchez un compromis","H"],["Demandez des faits pour trancher","M"]]},
   {t:"Votre rythme de décision :",o:[["Rapide, quitte à ajuster ensuite","D"],["Rapide, au feeling","E"],["Prudent, après avoir consulté","H"],["Réfléchi, après analyse","M"]]},
   {t:"Dans une présentation, vous soignez surtout…",o:[["La conclusion et les recommandations","D"],["L’accroche et l’impact","E"],["L’interaction avec le public","H"],["L’exactitude des données","M"]]},
   {t:"On vous reproche parfois d’être…",o:[["Trop autoritaire","D"],["Trop dispersé(e)","E"],["Trop conciliant(e)","H"],["Trop perfectionniste","M"]]},
   {t:"Ce qui vous motive le plus :",o:[["Relever des défis","D"],["Être reconnu(e)","E"],["Travailler dans un bon climat","H"],["Faire les choses correctement","M"]]},
   {t:"Face à un changement imposé, vous voulez d’abord savoir…",o:[["Ce que ça change pour vos objectifs","D"],["Quelles opportunités il ouvre","E"],["Comment l’équipe va le vivre","H"],["La logique et les détails","M"]]}
  ]
 },
 "leadership": {
  title:"Style de leadership", short:"Leadership", color:"#2f6db5", letter:"L",
  desc:"Directif, Coach, Participatif ou Délégatif : identifiez votre façon naturelle de manager et votre flexibilité.",
  time:"4 min", type:"choice",
  intro:["10 situations de management. Choisissez ce que vous feriez vraiment, pas ce qui vous semble idéal.","Si vous ne managez pas encore, imaginez-vous à la tête d’une équipe."],
  questions:[
   {t:"Un nouveau collaborateur arrive dans votre équipe. Vous…",o:[["Lui donnez des consignes précises et contrôlez souvent","DIR"],["Lui expliquez le pourquoi et l’accompagnez pas à pas","COA"],["Lui demandez comment il souhaite s’intégrer","PAR"],["Le laissez trouver ses marques en restant disponible","DEL"]]},
   {t:"Un objectif important est menacé. Vous…",o:[["Fixez un plan d’action et le pilotez vous-même","DIR"],["Réunissez l’équipe pour expliquer l’enjeu et motiver","COA"],["Co-construisez le plan de rattrapage avec l’équipe","PAR"],["Faites confiance aux plus expérimentés pour redresser la barre","DEL"]]},
   {t:"Un collaborateur expérimenté perd en motivation. Vous…",o:[["Lui rappelez clairement ce qui est attendu","DIR"],["Lui faites un feedback et fixez ensemble des objectifs","COA"],["L’écoutez et l’impliquez davantage dans les décisions","PAR"],["Lui confiez un projet en totale autonomie","DEL"]]},
   {t:"Une décision importante doit être prise. Vous…",o:[["Décidez seul(e) et annoncez","DIR"],["Décidez, puis expliquez et convainquez","COA"],["Décidez après avoir consulté l’équipe","PAR"],["Laissez l’équipe décider","DEL"]]},
   {t:"Votre équipe maîtrise parfaitement un process. Vous…",o:[["Continuez à vérifier chaque étape","DIR"],["Proposez des pistes d’amélioration","COA"],["Organisez un point pour recueillir leurs idées","PAR"],["Les laissez faire et vous concentrez sur autre chose","DEL"]]},
   {t:"En réunion d’équipe, vous parlez…",o:[["La majorité du temps, pour cadrer","DIR"],["Beaucoup, pour expliquer et encourager","COA"],["Autant que les autres","PAR"],["Peu : vous laissez l’équipe animer","DEL"]]},
   {t:"Un conflit éclate entre deux collaborateurs. Vous…",o:[["Tranchez rapidement","DIR"],["Recevez chacun pour l’aider à prendre du recul","COA"],["Organisez une discussion pour qu’ils trouvent une solution ensemble","PAR"],["Les laissez régler cela entre eux","DEL"]]},
   {t:"Un membre de l’équipe commet une erreur. Vous…",o:[["Renforcez les contrôles","DIR"],["En faites une occasion d’apprendre","COA"],["Analysez collectivement les causes","PAR"],["Lui faites confiance pour corriger lui-même","DEL"]]},
   {t:"Pour vous, un bon manager est celui qui…",o:[["Fixe le cap clairement","DIR"],["Fait grandir ses collaborateurs","COA"],["Fédère et implique","PAR"],["Rend son équipe autonome","DEL"]]},
   {t:"Un projet innovant démarre. Vous…",o:[["Définissez la méthode et le planning","DIR"],["Partagez votre vision et coachez les porteurs","COA"],["Lancez un brainstorming collectif","PAR"],["Confiez le projet à un volontaire","DEL"]]}
  ]
 },
 "resilience": {
  title:"Résilience face au stress", short:"Résilience", color:"#b0802a", letter:"R",
  desc:"Mesurez vos ressources face à la pression : maîtrise émotionnelle, optimisme, soutien et récupération.",
  time:"3 min", type:"likert",
  intro:["Répondez en pensant à ces dernières semaines.","Ce questionnaire d’auto-réflexion n’est pas un outil médical et ne pose aucun diagnostic."],
  questions:[
   {t:"Face à un imprévu, je garde mon calme.",k:"EMO"},
   {t:"Après un échec, je finis par en tirer quelque chose de positif.",k:"OPT"},
   {t:"Je peux compter sur des proches quand ça ne va pas.",k:"SOU"},
   {t:"Je dors suffisamment pour me sentir reposé(e).",k:"REC"},
   {t:"Une petite contrariété peut gâcher toute ma journée.",k:"EMO",r:1},
   {t:"Quand un problème survient, j’imagine souvent le pire.",k:"OPT",r:1},
   {t:"J’ai du mal à demander de l’aide.",k:"SOU",r:1},
   {t:"J’ai du mal à déconnecter du travail le soir ou le week-end.",k:"REC",r:1},
   {t:"Je sais identifier ce que je ressens quand je suis sous pression.",k:"EMO"},
   {t:"Je suis confiant(e) dans ma capacité à surmonter les difficultés.",k:"OPT"},
   {t:"Je sais déléguer ou dire non quand je suis surchargé(e).",k:"SOU"},
   {t:"Je pratique régulièrement une activité qui me ressource (sport, loisir, nature…).",k:"REC"}
  ]
 }
};

/* ============ INTERPRÉTATIONS ============ */
const B5 = {
 O:{n:"Ouverture",h:"Curieux(se) et imaginatif(ve), vous aimez les idées nouvelles, l’art et l’abstraction.",m:"Vous combinez goût de la nouveauté et attachement au concret.",l:"Pragmatique, vous préférez les approches éprouvées et les sujets concrets."},
 C:{n:"Conscience",h:"Organisé(e), fiable et persévérant(e), vous allez au bout de ce que vous commencez.",m:"Vous alternez entre rigueur et souplesse selon les enjeux.",l:"Spontané(e) et flexible, vous préférez l’improvisation aux plans détaillés."},
 E:{n:"Extraversion",h:"Vous tirez votre énergie des échanges, aimez être entouré(e) et prenez facilement la parole.",m:"À l’aise en groupe comme seul(e), vous dosez vos interactions selon le contexte.",l:"Vous préférez les échanges en petit comité et rechargez vos batteries dans le calme."},
 A:{n:"Agréabilité",h:"Empathique et coopératif(ve), vous cherchez l’harmonie et accordez facilement votre confiance.",m:"Vous savez être bienveillant(e) tout en défendant vos intérêts.",l:"Direct(e) et indépendant(e), vous n’hésitez pas à challenger les autres."},
 S:{n:"Stabilité émotionnelle",h:"Vous restez calme sous pression et récupérez vite des contrariétés.",m:"Vous gérez bien la plupart des tensions, avec quelques moments plus sensibles.",l:"Vous ressentez les émotions intensément : plus réactif(ve) au stress, mais aussi très attentif(ve) aux risques."}
};
const TYPES = {
 ISTJ:["Le Gardien","Fiable, méthodique, attaché(e) aux faits et aux engagements."],
 ISFJ:["Le Protecteur","Discret(e) et dévoué(e), attentif(ve) aux besoins concrets des autres."],
 INFJ:["Le Visionnaire","Intuitif(ve) et idéaliste, guidé(e) par des valeurs profondes."],
 INTJ:["Le Stratège","Indépendant(e) et analytique, vous concevez des plans à long terme."],
 ISTP:["L’Artisan","Pragmatique et calme, vous excellez à résoudre des problèmes concrets."],
 ISFP:["L’Artiste","Sensible et authentique, vous vivez selon vos valeurs, dans l’instant."],
 INFP:["L’Idéaliste","Créatif(ve) et sincère, en quête de sens et d’harmonie."],
 INTP:["Le Penseur","Curieux(se) et logique, passionné(e) par les idées et les systèmes."],
 ESTP:["Le Fonceur","Énergique et réaliste, vous agissez vite et aimez le concret."],
 ESFP:["L’Animateur","Chaleureux(se) et spontané(e), vous mettez de la vie partout."],
 ENFP:["L’Inspirateur","Enthousiaste et créatif(ve), vous voyez des possibilités partout."],
 ENTP:["L’Inventeur","Vif(ve) et ingénieux(se), vous adorez débattre et innover."],
 ESTJ:["Le Gestionnaire","Organisé(e) et décidé(e), vous structurez et faites avancer les choses."],
 ESFJ:["Le Rassembleur","Sociable et attentionné(e), vous créez la cohésion autour de vous."],
 ENFJ:["Le Mentor","Charismatique et empathique, vous faites grandir les autres."],
 ENTJ:["Le Bâtisseur","Leader stratégique, vous fixez le cap et mobilisez."]
};
const AXES = [["E","I","Extraversion","Introversion","Énergie tournée vers l’extérieur","Énergie tournée vers l’intérieur"],
 ["S","N","Sensation","Intuition","Concret, faits, expérience","Possibilités, vision, sens"],
 ["T","F","Pensée","Sentiment","Logique et objectivité","Valeurs et harmonie"],
 ["J","P","Jugement","Perception","Structure et planification","Flexibilité et adaptation"]];
const COMM = {
 D:{n:"Le Pilote",d:"Orienté(e) résultats, direct(e) et décidé(e). Vous aimez l’efficacité et garder le contrôle.",p:"Prendre le temps d’écouter avant de trancher, et reconnaître les émotions de vos interlocuteurs.",w:"Soyez bref, factuel et orienté résultat."},
 E:{n:"L’Inspirant",d:"Enthousiaste, communicatif(ve) et créatif(ve). Vous entraînez les autres par votre énergie.",p:"Structurer vos idées, assurer le suivi et laisser plus d’espace aux autres.",w:"Montrez de l’enthousiasme, parlez vision et reconnaissance."},
 H:{n:"Le Facilitateur",d:"À l’écoute, patient(e) et loyal(e). Vous créez la confiance et la cohésion.",p:"Oser dire non, exprimer vos désaccords et décider plus vite.",w:"Prenez le temps de la relation, rassurez, évitez la brusquerie."},
 M:{n:"L’Analyste",d:"Précis(e), logique et rigoureux(se). Vous fondez vos positions sur les faits.",p:"Accepter l’imperfection, synthétiser davantage et partager vos ressentis.",w:"Apportez des données, de la structure et laissez du temps."}
};
const LEAD = {
 DIR:{n:"Directif",d:"Vous cadrez, décidez et contrôlez. Très efficace en situation d’urgence ou avec des collaborateurs débutants.",r:"Peut freiner l’autonomie et l’engagement sur la durée."},
 COA:{n:"Coach",d:"Vous expliquez, motivez et accompagnez la progression. Idéal pour des collaborateurs en apprentissage.",r:"Chronophage ; peut sembler paternaliste avec des profils expérimentés."},
 PAR:{n:"Participatif",d:"Vous impliquez l’équipe et co-construisez. Idéal avec des collaborateurs compétents qui ont besoin de confiance.",r:"Décisions plus lentes ; flou si le cadre n’est pas clair."},
 DEL:{n:"Délégatif",d:"Vous donnez autonomie et responsabilité. Idéal avec des experts motivés.",r:"Sentiment d’abandon si l’équipe n’est pas prête."}
};
const RES = {
 EMO:{n:"Maîtrise émotionnelle",t:"Nommez l’émotion quand elle monte, puis prenez 3 respirations lentes avant de répondre."},
 OPT:{n:"Optimisme réaliste",t:"Face à un problème, listez 3 scénarios (pire, probable, meilleur) : le probable est rarement le pire."},
 SOU:{n:"Soutien & limites",t:"Identifiez deux personnes à qui demander de l’aide, et entraînez-vous à dire « pas maintenant »."},
 REC:{n:"Récupération",t:"Fixez une heure de déconnexion le soir et protégez un moment ressourçant chaque semaine."}
};

