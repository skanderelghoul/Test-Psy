/* Moteur de la plateforme : navigation, calcul des scores, affichage des résultats. */
/* ============ ÉTAT & STOCKAGE ============ */
let S = null;
const app = document.getElementById("app");
function loadHist(){try{return JSON.parse(localStorage.getItem("mesc_hist")||"[]")}catch(e){return []}}
function saveHist(h){try{localStorage.setItem("mesc_hist",JSON.stringify(h.slice(0,30)))}catch(e){}}
function toast(m){const t=document.getElementById("toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2000)}
function shuffle(a){a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function setAccent(c){document.documentElement.style.setProperty("--accent",c)}
function go(hash){if(location.hash!=="#"+hash){location.hash=hash}else route()}

/* ============ ÉCRANS ============ */
function home(){
 setAccent("#c2552d");
 const hist=loadHist();
 const doneIds=new Set(hist.map(h=>h.id));
 let h=`<div class="fade"><div class="eyebrow">Plateforme d’auto-découverte</div>
 <h1 style="margin-top:8px">Mieux se connaître</h1>
 <p class="lead">Cinq tests courts pour explorer votre personnalité, votre façon de communiquer, de diriger et de faire face au stress. Résultats immédiats et détaillés.</p>
 <div class="grid">`;
 for(const [id,t] of Object.entries(TESTS)){
  h+=`<button class="card test-card" style="--c:${t.color}" onclick="go('${id}')">
   ${doneIds.has(id)?'<span class="done-badge">✓ Fait</span>':''}
   <div class="dot">${t.letter}</div><h3>${t.title}</h3><p>${t.desc}</p>
   <div class="meta"><span class="chip">${t.questions.length} questions</span><span class="chip">${t.time}</span></div></button>`;
 }
 h+=`</div>`;
 if(hist.length){
  h+=`<h2 class="section-title">Vos derniers résultats</h2><div class="card">`;
  for(const x of hist.slice(0,8)){
   h+=`<div class="hist-item"><div><b>${TESTS[x.id]?.title||""}</b>${x.summary}</div><span>${x.date}</span></div>`;
  }
  h+=`</div><button class="link-btn" onclick="clearHist()">Effacer l’historique</button>`;
 }
 h+=`<footer>Outils d’auto-réflexion à visée de développement personnel — ils ne remplacent pas une évaluation par un professionnel.<br>Vos réponses restent sur votre appareil.</footer></div>`;
 app.innerHTML=h;
}
function clearHist(){saveHist([]);home();toast("Historique effacé")}

function intro(id){
 const t=TESTS[id]; setAccent(t.color);
 app.innerHTML=`<div class="fade intro">
  <div class="top"><button class="back" onclick="go('accueil')">← Tous les tests</button></div>
  <div class="eyebrow">${t.questions.length} questions · ${t.time}</div>
  <h1 style="margin-top:8px">${t.title}</h1>
  <p class="lead">${t.desc}</p>
  <ul>${t.intro.map(x=>`<li>${x}</li>`).join("")}</ul>
  <button class="primary" onclick="start('${id}')">Commencer le test</button></div>`;
}

function start(id){
 const t=TESTS[id];
 const qs=t.questions.map(q=>{
  if(t.type==="likert") return {...q,opts:LIKERT.map((l,i)=>({t:l,v:i+1}))};
  const o=q.o.map(([tx,k])=>({t:tx,k}));
  return {...q,opts:t.noShuffle?o:shuffle(o)};
 });
 S={id,qs,ans:new Array(qs.length).fill(null),i:0};
 renderQ();
}

function renderQ(){
 const t=TESTS[S.id], q=S.qs[S.i], n=S.qs.length;
 const pct=Math.round(S.i/n*100);
 const lik=t.type==="likert";
 app.innerHTML=`<div>
  <div class="top"><button class="back" onclick="quit()">✕ Quitter</button><span class="qcount">${S.i+1} / ${n}</span></div>
  <div class="progress"><i style="width:${pct}%"></i></div>
  <div class="fade"><div class="question">${q.t}</div>
  <div class="options ${lik?'likert':''}">
   ${q.opts.map((o,j)=>`<button class="opt ${S.ans[S.i]===j?'sel':''}" onclick="pick(${j})">${lik?`<span class="n">${j+1}</span>`:''}<span>${o.t}</span></button>`).join("")}
  </div></div>
  <div class="nav"><button class="ghost" ${S.i===0?'disabled':''} onclick="prev()">← Précédent</button>
  ${S.ans[S.i]!==null&&S.i<n-1?'<button class="ghost" onclick="next()">Suivant →</button>':''}</div></div>`;
}
let lock=false;
function pick(j){
 if(lock) return; S.ans[S.i]=j; lock=true;
 document.querySelectorAll(".opt").forEach((b,k)=>b.classList.toggle("sel",k===j));
 setTimeout(()=>{lock=false; if(S.i<S.qs.length-1){S.i++;renderQ()}else finish()},230);
}
function prev(){if(S.i>0){S.i--;renderQ()}}
function next(){if(S.i<S.qs.length-1){S.i++;renderQ()}}
function quit(){S=null;go('accueil')}

/* ============ CALCUL DES RÉSULTATS ============ */
function score(){
 const t=TESTS[S.id], sc={}, cnt={};
 S.qs.forEach((q,i)=>{
  const o=q.opts[S.ans[i]];
  if(t.type==="likert"){const v=q.r?6-o.v:o.v; sc[q.k]=(sc[q.k]||0)+v; cnt[q.k]=(cnt[q.k]||0)+1}
  else{sc[o.k]=(sc[o.k]||0)+1}
 });
 return {sc,cnt};
}
const lvl=p=>p>=67?"h":p>=34?"m":"l";
const lvlTxt={h:"Élevé",m:"Modéré",l:"Faible"};
function bar(label,right,pct,txt){
 return `<div class="bar-row"><div class="lbl">${label}<span>${right}</span></div><div class="bar"><i data-w="${pct}"></i></div>${txt?`<p>${txt}</p>`:''}</div>`;
}

function finish(){
 const id=S.id, t=TESTS[id], {sc,cnt}=score();
 let hero="", body="", summary="", copy="";
 if(id==="big-five"){
  const p={};
  for(const k of ["O","C","E","A","N"]){p[k]=Math.round((sc[k]-cnt[k])/(cnt[k]*4)*100)}
  p.S=100-p.N; delete p.N;
  const order=["O","C","E","A","S"];
  const top=order.slice().sort((a,b)=>p[b]-p[a]);
  hero=`<div class="eyebrow">Votre trait le plus marqué</div><div class="big">${B5[top[0]].n}</div><p>${B5[top[0]].h}</p>`;
  body=`<div class="card"><h3 style="margin-bottom:16px">Votre profil sur les 5 dimensions</h3><div class="bars">${order.map(k=>bar(B5[k].n,`${lvlTxt[lvl(p[k])]} · ${p[k]}%`,p[k],B5[k][lvl(p[k])])).join("")}</div>
  <div class="note">Le Big Five décrit des tendances sur un continuum : aucun score n’est « bon » ou « mauvais ». Chaque position a ses atouts selon le contexte.</div></div>`;
  summary=order.map(k=>`${B5[k].n} ${p[k]}%`).join(" · ");
  copy=`Mes 5 grands traits :\n`+order.map(k=>`• ${B5[k].n} : ${p[k]}% (${lvlTxt[lvl(p[k])]})`).join("\n");
 }
 if(id==="profil"){
  let code="", rows="";
  for(const [a,b,na,nb,da,db] of AXES){
   const va=sc[a]||0, vb=sc[b]||0, tot=va+vb, pa=Math.round(va/tot*100);
   const win=va>=vb?a:b; code+=win;
   rows+=`<div class="bar-row"><div class="lbl">${win===a?na:nb}<span>${Math.max(pa,100-pa)}%</span></div>
    <div class="bar"><i data-w="${Math.max(pa,100-pa)}" style="${win===b?'margin-left:auto':''}"></i></div><div class="dual"><span>${a} · ${na}</span><span>${nb} · ${b}</span></div>
    <p>${win===a?da:db}</p></div>`;
  }
  const [nm,ds]=TYPES[code];
  hero=`<div class="eyebrow">Votre profil</div><div class="big">${code}</div><h2>${nm}</h2><p>${ds}</p>`;
  body=`<div class="card"><h3 style="margin-bottom:16px">Vos 4 préférences</h3><div class="bars">${rows}</div>
   <div class="note">Profil inspiré de la typologie de C. G. Jung, en version simplifiée. Les préférences ne sont pas des capacités : vous pouvez tout à fait utiliser le pôle opposé quand la situation l’exige.</div></div>`;
  summary=`${code} — ${nm}`; copy=`Mon profil de préférences : ${code} — ${nm}\n${ds}`;
 }
 if(id==="communication"){
  const ks=["D","E","H","M"], tot=S.qs.length, p={};
  ks.forEach(k=>p[k]=Math.round((sc[k]||0)/tot*100));
  const ord=ks.slice().sort((a,b)=>p[b]-p[a]), d=ord[0], s=ord[1];
  hero=`<div class="eyebrow">Votre style dominant</div><div class="big">${COMM[d].n}</div><p>${COMM[d].d}</p><p style="margin-top:10px">Style secondaire : <b>${COMM[s].n}</b></p>`;
  body=`<div class="card"><h3 style="margin-bottom:16px">Répartition de vos styles</h3><div class="bars">${ord.map(k=>bar(COMM[k].n,p[k]+"%",p[k])).join("")}</div></div>
  <div class="card" style="margin-top:14px"><h3>Pour progresser</h3><div class="stack"><div class="tip"><b>Votre axe de développement</b><p>${COMM[d].p}</p></div></div></div>
  <div class="card" style="margin-top:14px"><h3>Comment parler aux autres styles</h3><div class="stack">${ks.filter(k=>k!==d).map(k=>`<div class="tip"><b>Avec un profil ${COMM[k].n.replace(/^(Le |L’)/,"")}</b><p>${COMM[k].w}</p></div>`).join("")}</div></div>`;
  summary=`${COMM[d].n} (${p[d]}%), puis ${COMM[s].n}`;
  copy=`Mon style de communication :\n`+ord.map(k=>`• ${COMM[k].n} : ${p[k]}%`).join("\n");
 }
 if(id==="leadership"){
  const ks=["DIR","COA","PAR","DEL"], tot=S.qs.length, p={};
  ks.forEach(k=>p[k]=Math.round((sc[k]||0)/tot*100));
  const ord=ks.slice().sort((a,b)=>p[b]-p[a]), d=ord[0];
  const flex=ks.filter(k=>p[k]>=20).length;
  const flexTxt=flex>=3?"Grande flexibilité : vous mobilisez plusieurs styles selon les situations, un vrai atout de manager.":flex===2?"Flexibilité moyenne : vous alternez entre deux styles principaux. Explorez les deux autres pour gagner en adaptabilité.":"Style très affirmé : efficace dans certaines situations, mais pensez à varier selon l’autonomie de chaque collaborateur.";
  hero=`<div class="eyebrow">Votre style naturel</div><div class="big">${LEAD[d].n}</div><p>${LEAD[d].d}</p>`;
  body=`<div class="card"><h3 style="margin-bottom:16px">Votre palette de styles</h3><div class="bars">${ord.map(k=>bar(LEAD[k].n,p[k]+"%",p[k])).join("")}</div>
   <div class="note"><b>Flexibilité : ${flex}/4.</b> ${flexTxt}</div></div>
  <div class="card" style="margin-top:14px"><h3>Forces et vigilances</h3><div class="stack">${ord.map(k=>`<div class="tip"><b>${LEAD[k].n} — ${p[k]}%</b><p>${LEAD[k].d} <i>Vigilance :</i> ${LEAD[k].r}</p></div>`).join("")}</div>
   <div class="note">Selon le modèle du leadership situationnel (Hersey &amp; Blanchard), aucun style n’est supérieur : l’efficacité vient de l’adaptation du style au niveau de compétence et de motivation de chaque collaborateur.</div></div>`;
  summary=`${LEAD[d].n} (${p[d]}%), flexibilité ${flex}/4`;
  copy=`Mon style de leadership :\n`+ord.map(k=>`• ${LEAD[k].n} : ${p[k]}%`).join("\n")+`\nFlexibilité : ${flex}/4`;
 }
 if(id==="resilience"){
  const ks=["EMO","OPT","SOU","REC"], p={};
  ks.forEach(k=>p[k]=Math.round((sc[k]-cnt[k])/(cnt[k]*4)*100));
  const g=Math.round(ks.reduce((a,k)=>a+p[k],0)/4);
  const band=g>=75?["Résilience solide","Vous disposez de ressources variées pour traverser les périodes de pression."]:g>=55?["Bonne base, à renforcer","Vos fondations sont là ; quelques leviers ciblés peuvent faire une vraie différence."]:["Zone de vigilance","Vos ressources semblent sollicitées en ce moment. Prenez soin de vous et appuyez-vous sur votre entourage."];
  const weak=ks.slice().sort((a,b)=>p[a]-p[b]).slice(0,2);
  hero=`<div class="eyebrow">Votre indice de résilience</div><div class="big">${g}<span style="font-size:.45em">/100</span></div><h2>${band[0]}</h2><p>${band[1]}</p>`;
  body=`<div class="card"><h3 style="margin-bottom:16px">Vos 4 ressources</h3><div class="bars">${ks.map(k=>bar(RES[k].n,p[k]+"%",p[k])).join("")}</div></div>
  <div class="card" style="margin-top:14px"><h3>Vos leviers prioritaires</h3><div class="stack">${weak.map(k=>`<div class="tip"><b>${RES[k].n}</b><p>${RES[k].t}</p></div>`).join("")}</div>
  <div class="note">Ce questionnaire est un outil d’auto-réflexion, pas un outil médical. Si vous ressentez un épuisement, une anxiété ou une tristesse qui durent, parlez-en à un médecin ou à un professionnel de santé.</div></div>`;
  summary=`Indice ${g}/100 — ${band[0]}`;
  copy=`Ma résilience face au stress : ${g}/100 (${band[0]})\n`+ks.map(k=>`• ${RES[k].n} : ${p[k]}%`).join("\n");
 }
 const hist=loadHist();
 hist.unshift({id,summary,date:new Date().toLocaleDateString("fr-FR",{day:"numeric",month:"short"})});
 saveHist(hist);
 window._copy=copy;
 app.innerHTML=`<div class="fade">
  <div class="top"><button class="back" onclick="go('accueil')">← Tous les tests</button><span class="qcount">${t.title}</span></div>
  <div class="card hero-res">${hero}</div>
  <div style="margin-top:14px">${body}</div>
  <div class="actions"><button class="primary" onclick="copyRes()">Copier mes résultats</button>
  <button class="secondary" onclick="start('${id}')">Refaire le test</button>
  <button class="secondary" onclick="go('accueil')">Autres tests</button></div></div>`;
 window.scrollTo(0,0);
 requestAnimationFrame(()=>setTimeout(()=>document.querySelectorAll(".bar i").forEach(b=>b.style.width=b.dataset.w+"%"),60));
 S=null;
}
function copyRes(){
 try{navigator.clipboard.writeText(window._copy).then(()=>toast("Résultats copiés"),()=>toast("Copie impossible sur cet appareil"))}
 catch(e){toast("Copie impossible sur cet appareil")}
}

/* ============ NAVIGATION ============ */
function route(){
 const h=location.hash.replace("#","");
 if(TESTS[h]) intro(h); else home();
 window.scrollTo(0,0);
}
window.addEventListener("hashchange",route);
route();
