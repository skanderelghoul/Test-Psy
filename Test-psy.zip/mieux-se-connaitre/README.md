# Mieux se connaître — Tests de personnalité

Plateforme web gratuite de tests de personnalité et d'auto-découverte, en français, pensée d'abord pour le mobile.

## Les 5 tests

| Test | Questions | Ce qu'il mesure |
|---|---|---|
| **Les 5 grands traits (Big Five)** | 20 | Ouverture, conscience, extraversion, agréabilité, stabilité émotionnelle |
| **Profil de préférences** | 12 | 4 préférences inspirées de Jung, 16 profils possibles |
| **Style de communication** | 12 | Pilote, Inspirant, Facilitateur, Analyste |
| **Style de leadership** | 10 | Directif, Coach, Participatif, Délégatif + flexibilité |
| **Résilience face au stress** | 12 | Maîtrise émotionnelle, optimisme, soutien, récupération |

## Fonctionnalités

- Résultats immédiats et détaillés : barres de score, interprétations, conseils.
- Historique des résultats enregistré dans le navigateur (`localStorage`). Aucune donnée n'est envoyée à un serveur.
- Lien direct vers chaque test : `#big-five`, `#profil`, `#communication`, `#leadership`, `#resilience`.
- Bouton « Copier mes résultats ».
- Mode sombre automatique.
- Aucune dépendance et aucune étape de build : HTML, CSS et JavaScript simples.

## Structure

```
mieux-se-connaitre/
├── index.html      # Page principale
├── css/style.css   # Styles
├── js/data.js      # Questions et interprétations des tests
└── js/app.js       # Navigation, calcul des scores, affichage
```

Pour modifier une question ou en ajouter une, il suffit de modifier `js/data.js`.

## Lancer en local

Ouvrez simplement `index.html` dans votre navigateur. Vous pouvez aussi lancer un petit serveur :

```bash
python3 -m http.server 8000
# puis ouvrez http://localhost:8000
```

## Mettre en ligne avec GitHub Pages

1. Créez un nouveau dépôt sur GitHub (par exemple `mieux-se-connaitre`).
2. Envoyez-y les fichiers :
   ```bash
   git init
   git add .
   git commit -m "Première version de la plateforme"
   git branch -M main
   git remote add origin https://github.com/VOTRE-NOM/mieux-se-connaitre.git
   git push -u origin main
   ```
3. Sur GitHub, ouvrez **Settings → Pages**. Dans **Source**, choisissez **Deploy from a branch**, puis la branche `main` et le dossier `/ (root)`. Cliquez sur **Save**.
4. Au bout d'une minute environ, le site est en ligne à l'adresse `https://VOTRE-NOM.github.io/mieux-se-connaitre/`.

## Sources et avertissement

- Le test Big Five reprend les 20 items du **Mini-IPIP** (Donnellan, Oswald, Baird & Lucas, 2006), tirés de l'International Personality Item Pool (domaine public). Les items ont été traduits librement en français.
- Le profil de préférences est une version simplifiée, inspirée de la typologie de C. G. Jung. Il n'a aucun lien avec un instrument commercial.
- Le test de leadership s'inspire du modèle du leadership situationnel (Hersey & Blanchard).
- Ces questionnaires servent à la réflexion et au développement personnel. Ce ne sont **pas des outils de diagnostic** : ils ne remplacent pas une évaluation par un professionnel.

## Licence

MIT — voir [LICENSE](LICENSE).
